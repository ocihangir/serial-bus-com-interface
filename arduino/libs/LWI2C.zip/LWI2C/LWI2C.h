
/* LWI2C.h
 * A Light Weight I2C controller for Arduino.
 * Standard Wire lib has some features that are
 * not necessary for a low level application.
 * This library implements lower level I2C to
 * be light weight and faster.
 * 
 * This library is a part of project PaddleFish.
 * 
 * Ozan Cihangir - 2015
*/

#ifndef LWI2C_h
#define LWI2C_h

#include "Arduino.h"

// I2C related constants
#define START_CONDITION 0x00
#define SEND_CONDITION 0x01
#define SEND_CONDITION_NACK 0x02
#define STOP_CONDITION 0x03
#define REPEATED_START_CONDITION 0x04

// Frequency constants
#define FCLK 160000
#define FCLK_PR1 80000
#define FCLK_PR4 20000
#define FCLK_PR16 5000
#define FCLK_PR64 1250

#define CONS_16DIV2_PRE1 8
#define CONS_16DIV2_PRE4 2
#define CONS_16DIV2_PRE16 1 //50 //0.5*100
#define CONS_16DIV2_PRE64 0 //125 //0.125*1000

class LWI2C
{
public:
	char* i2c_read(char devAddress,char length);
	void i2c_write(char devAddress, char length, char* data);
	void i2c_start();
	void i2c_stop();
	void i2c_repeated_start();
	void i2c_set_speed(unsigned long speed);
private:
	char i2c_tx(char mode);
	void i2cError();
};
#endif
